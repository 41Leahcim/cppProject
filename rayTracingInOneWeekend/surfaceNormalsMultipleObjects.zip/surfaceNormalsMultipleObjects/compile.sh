g++ sources/Color.cpp sources/common.cpp sources/HittableList.cpp sources/Ray.cpp sources/Sphere.cpp sources/Vec3.cpp sources/test.cpp -O2 -o test
