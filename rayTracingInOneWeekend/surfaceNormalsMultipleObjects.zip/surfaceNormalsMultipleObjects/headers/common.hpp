#ifndef RTWEEKEND_HPP

#define RTWEEKEND_HPP

#include <limits>

// Constants
const double infinity = std::numeric_limits<double>::infinity();
const double pi = 3.1415926535897932385;

// Utility Functions
inline double degreesToRadians(double);

// Common headers
#include "HittableList.hpp"
#include "Color.hpp"
#include "Sphere.hpp"

#endif
