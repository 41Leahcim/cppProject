#ifndef COLOR_H

#define COLOR_H

#include <iostream>

#include "Vec3.hpp"

void writeColor(std::ostream&, const Color&);

#endif
