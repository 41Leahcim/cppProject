#include <iostream>

#include "Color.hpp"
#include "Vec3.hpp"

int main(){
    // Image width and height
    const uint16_t imageWidth = 1080, imageHeight = 1920;

    // Render the image
    std::cout << "P3\n" << imageWidth << " " << imageHeight << "\n255\n";
    for(int16_t y = imageHeight - 1;y >= 0;y--){
        std::cerr << "\rScanlines remaining: " << y << " " << std::flush;
        for(uint16_t x = 0;x < imageWidth;x++){
            double r = double(x) / (imageWidth - 1);
            double g = double(y) / (imageHeight - 1);
            double b = 1 - (r + g) / 2;
            Color pixelColor(r, g, b);
            writeColor(std::cout, pixelColor);
        }
    }
    std::cerr << "\nDone.\n";
}
