#include "../headers/Camera.hpp"

Camera::Camera(){
    double aspectRatio = 16 / 9.0;
    double viewportHeight = 2;
    double viewportWidth = aspectRatio * viewportHeight;
    double focalLength = 1;

    origin = Point3(0, 0, 0);
    horizontal = Vec3(viewportWidth, 0, 0);
    vertical = Vec3(0, viewportHeight, 0);
    lowerLeftCorner = origin - horizontal / 2 - vertical / 2 - Vec3(0, 0, focalLength);
}

Ray Camera::getRay(double u, double v) const{
    return Ray(origin, lowerLeftCorner + u * horizontal + v * vertical - origin);
}
