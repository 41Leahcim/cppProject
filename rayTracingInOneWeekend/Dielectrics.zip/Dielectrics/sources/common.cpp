#include "../headers/common.hpp"

// Utility Functions
inline double degreesToRadians(double degrees){
    return degrees * pi / 180;
}
