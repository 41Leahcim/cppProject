#include "Color.hpp"
#include "Ray.hpp"
#include "Vec3.hpp"

#include <iostream>

bool hitSphere(const Point3& center, double radius, const Ray& r){
    Vec3 oc = r.getOrigin() - center;
    double a = dot(r.getDirection(), r.getDirection());
    double b = 2.0 * dot(oc, r.getDirection());
    double c = dot(oc, oc) - radius * radius;
    double discriminant = b * b - 4 * a * c;
    return discriminant > 0;
}

Color rayColor(const Ray& ray){
    if(hitSphere(Point3(0, 0, 1), 0.5, ray)){
        return Color(1, 0, 0);
    }
    Vec3 unitDirection = unitVector(ray.getDirection());
    double time = 0.5 * (unitDirection.getY() + 1);
    return (1.0 - time) * Color(1, 1, 1) + time * Color(0.5, 0.7, 1);
}

int main(){
    // set the image properties
    const double aspectRatio = 16 / 9.0;
    const uint16_t imageWith = 400;
    const uint16_t imageHeight = static_cast<int>(imageWith / aspectRatio);

    // set the camera properties
    double viewportHeight = 2;
    double viewportWidth = aspectRatio * viewportHeight;
    double focalLength = 1;

    Point3 origin(0, 0, 0);
    Vec3 horizontal(viewportWidth, 0, 0);
    Vec3 vertical(0, viewportHeight, 0);
    Vec3 lowerLeftCorner = origin - horizontal / 2 - vertical / 2 - Vec3(0, 0, focalLength);

    // Render the image
    std::cout << "P3\n" << imageWith << " " << imageHeight << "\n255\n";
    for(int16_t y = imageHeight - 1;y >= 0;y--){
        std::cerr << "\rScanlinesremaining: " << y << " " << std::flush;
        for(uint16_t x = 0;x < imageWith;x++){
            double u = double(x) / (imageWith - 1);
            double v = double(y) / (imageHeight - 1);
            Ray ray(origin, lowerLeftCorner + u * horizontal + v * vertical - origin);
            Color pixelColor = rayColor(ray);
            writeColor(std::cout, pixelColor);
        }
    }
    std::cerr << "\nDone\n";
}
