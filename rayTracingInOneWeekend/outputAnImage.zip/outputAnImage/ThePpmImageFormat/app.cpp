#include <iostream>

int main(){
    // define the width and height of the image
    const uint16_t imageWidth = 256, imageHeight = 256;

    // render the image
    std::cout << "P3\n" << imageWidth << " " << imageHeight << "\n255\n";
    for(int16_t y = imageHeight - 1;y >= 0;y--){
        for(uint16_t x = 0;x < imageWidth;x++){
            double r = double(x) / (imageWidth - 1);
            double g = double(y) / (imageHeight - 1);
            double b = 1 - (r + g) / 2;

            int ir = static_cast<int>(255.999 * r);
            int ig = static_cast<int>(255.999 * g);
            int ib = static_cast<int>(255.999 * b);
            std::cout << ir << " " << ig << " " << ib << "\n";
        }
    }
}
