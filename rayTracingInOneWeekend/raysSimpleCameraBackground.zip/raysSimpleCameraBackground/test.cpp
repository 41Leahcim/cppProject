#include "Color.hpp"
#include "Ray.hpp"
#include "Vec3.hpp"

#include <iostream>

Color rayColor(const Ray& ray){
    Vec3 unitDirection = unitVector(ray.getDirection());
    double time = 0.5 * (unitDirection.getY() + 1);
    return (1.0 - time) * Color(1, 1, 1) + time * Color(0.5, 0.7, 1);
}

int main(){
    // set the image properties
    const double aspectRatio = 16 / 9.0;
    const uint16_t imageWith = 400;
    const uint16_t imageHeight = static_cast<int>(imageWith / aspectRatio);

    // set the camera properties
    double viewportHeight = 2;
    double viewportWidth = aspectRatio * viewportHeight;
    double focalLength = 1;

    Point3 origin(0, 0, 0);
    Vec3 horizontal(viewportWidth, 0, 0);
    Vec3 vertical(0, viewportHeight, 0);
    Vec3 lowerLeftCorner = origin - horizontal / 2 - vertical / 2 - Vec3(0, 0, focalLength);

    // Render the image
    std::cout << "P3\n" << imageWith << " " << imageHeight << "\n255\n";
    for(int16_t y = imageHeight - 1;y >= 0;y--){
        std::cerr << "\rScanlinesremaining: " << y << " " << std::flush;
        for(uint16_t x = 0;x < imageWith;x++){
            double u = double(x) / (imageWith - 1);
            double v = double(y) / (imageHeight - 1);
            Ray ray(origin, lowerLeftCorner + u * horizontal + v * vertical - origin);
            Color pixelColor = rayColor(ray);
            writeColor(std::cout, pixelColor);
        }
    }
    std::cerr << "\nDone\n";
}
