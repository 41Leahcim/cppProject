#ifndef COLOR_HPP

#define COLOR_HPP

#include <iostream>

#include "Vec3.hpp"

void writeColor(std::ostream&, const Color&);

#endif
